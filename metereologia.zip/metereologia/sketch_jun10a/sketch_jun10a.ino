#include "DHT.h"
#include <Wire.h> 
#include <LiquidCrystal_I2C.h> 

// Configurações do LCD
#define col 16 
#define lin  2 
#define ende  0x27 
LiquidCrystal_I2C lcd(ende, col, lin);

// Configurações do DHT
#define DHTPIN A1
#define DHTTYPE DHT11
DHT dht(DHTPIN, DHTTYPE);

// Botão
#define BUTTON_PIN 3

// Temporizador para atualização automática
unsigned long ultimaAtualizacao = 0;
const unsigned long intervalo = 5000; // atualiza a cada 5 segundos

void setup() 
{
  Serial.begin(9600);
  dht.begin();

  lcd.init(); 
  lcd.backlight(); 
  lcd.clear();

  pinMode(BUTTON_PIN, INPUT_PULLUP); // botão com pull-up interno
}

void loop() 
{
  // Sempre mostra a temperatura e umidade (modo padrão)
  if (millis() - ultimaAtualizacao > intervalo) {
    float h = dht.readHumidity();
    float t = dht.readTemperature();

    if (!isnan(t) && !isnan(h)) {
      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print("Temp: ");
      lcd.print(t);
      lcd.print("C");

      lcd.setCursor(0, 1);
      lcd.print("Umid: ");
      lcd.print(h);
      lcd.print("%");
    } else {
      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print("Erro no sensor");
    }

    ultimaAtualizacao = millis();
  }

  // Se o botão for pressionado
  if (digitalRead(BUTTON_PIN) == LOW) {
    delay(50); // debounce simples
    if (digitalRead(BUTTON_PIN) == LOW) {
      float h = dht.readHumidity();

      lcd.clear();
      lcd.setCursor(0, 0);

      if (isnan(h)) {
        lcd.print("Erro ao ler!");
      } else {
        // Interpretação do clima com base na umidade
        if (h > 70) {
          lcd.print("Chuva provavel");
          lcd.setCursor(0, 1);
          lcd.print("Umid alta");
        } else if (h < 40) {
          lcd.print("Clima seco");
          lcd.setCursor(0, 1);
          lcd.print("Sem chuva");
        } else {
          lcd.print("Clima estavel");
          lcd.setCursor(0, 1);
          lcd.print("Umid moderada");
        }

        // Também mostra no serial
        Serial.print("Umidade: ");
        Serial.print(h);
        Serial.print(" % => ");
        if (h > 70) {
          Serial.println("Alta chance de chuva.");
        } else if (h < 40) {
          Serial.println("Tempo seco.");
        } else {
          Serial.println("Clima estável.");
        }
      }

      // Aguarda o botão ser solto
      while (digitalRead(BUTTON_PIN) == LOW);
      delay(500); // evita múltiplos cliques
    }
  }
}

