#include <SPI.h>
#include <MFRC522.h>
#include <Servo.h>
#include <Ultrasonic.h>
#include <Wire.h> 
#include <LiquidCrystal_I2C.h> 
#define col 16 
#define lin  2 
#define ende  0x27 
LiquidCrystal_I2C lcd(ende,col,lin);

// Pinos do módulo RFID
#define SS_PIN 10
#define RST_PIN 9

// Pinos do ultrassônico
#define pino_trigger 4
#define pino_echo 5

// Inicializações
Ultrasonic ultrasonic(pino_trigger, pino_echo);
MFRC522 mfrc522(SS_PIN, RST_PIN);
Servo myservo;

// UID autorizado
String uidAutorizado = "BD9C3423";

void setup() {
  Serial.begin(9600);
  SPI.begin();
  mfrc522.PCD_Init();
  myservo.attach(3);
  myservo.write(0); // Inicialmente fechado
  pinMode(2,OUTPUT);
  pinMode(6,OUTPUT);
  Serial.println("Aproxime o cartão RFID...");
  lcd.init(); 
  lcd.backlight(); 
  lcd.clear();
}

void loop() {
  lcd.setCursor(4,0); 
  lcd.print("aproxime");
  lcd.setCursor(3,1); 
  lcd.print("seu cartao ");
  
  // Verifica se há um novo cartão
  if (!mfrc522.PICC_IsNewCardPresent() || !mfrc522.PICC_ReadCardSerial()) {
    return;
  }

  // Lê o UID do cartão
  String uidLido = "";
  for (byte i = 0; i < mfrc522.uid.size; i++) {
    uidLido += String(mfrc522.uid.uidByte[i], HEX);
  }
  uidLido.toUpperCase();

  Serial.print("UID Lido: ");
  Serial.println(uidLido);

  // Verifica se o cartão é autorizado
  if (uidLido == uidAutorizado) {
    Serial.println("Cartão autorizado. Aguardando aproximação...");
    lcd.setCursor(3,0); // Coloca o cursor do display na coluna 1 e linha 1
    lcd.print("Autorizado");
    lcd.clear();
    digitalWrite(2,HIGH);
    
    // Aguarda aproximação por 5 segundos
    unsigned long tempoInicio = millis();
    while (millis() - tempoInicio < 5000) {
      long microsec = ultrasonic.timing();
      float cmMsec = ultrasonic.convert(microsec, Ultrasonic::CM);

      if (cmMsec <= 19) {
        Serial.println("Aproximação detectada!");
        Serial.println(cmMsec);
        myservo.write(90);
        lcd.setCursor(3,0); 
        lcd.print("Autorizado");
        delay(3000);
        lcd.clear();
        myservo.write(0); 
        digitalWrite(2,LOW); 
        break;
      }

      delay(100);
    }
  } else {
    Serial.println("Cartão nao autorizado.");
    lcd.setCursor(1,0); 
    lcd.print("nao Autorizado ");
    digitalWrite(6,HIGH);
    delay(3000);
    lcd.clear();
    digitalWrite(6,LOW);

  }

  
  mfrc522.PICC_HaltA();
  delay(1000);
}